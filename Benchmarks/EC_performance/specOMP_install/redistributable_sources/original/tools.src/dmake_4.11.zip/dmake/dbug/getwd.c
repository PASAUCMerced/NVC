char *
getwd(pathname)
char *pathname;
{
   return("delete this code if your getwd.c works correctly");
}
