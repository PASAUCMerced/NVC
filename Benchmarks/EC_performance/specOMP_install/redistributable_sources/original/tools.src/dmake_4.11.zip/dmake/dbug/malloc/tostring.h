/*
 * (c) Copyright 1990 Conor P. Cahill (uunet!virtech!cpcahil).  
 * You may copy, distribute, and use this software as long as this
 * copyright statement is not removed.
 */
/*
 * $Id: tostring.h,v 1.2 2006/07/25 10:10:32 rt Exp $
 */
#define B_BIN	 2
#define B_DEC	10
#define B_HEX	16
#define B_OCTAL	 8

